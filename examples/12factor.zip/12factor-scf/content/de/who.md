Wer sollte dieses Dokument lesen?
==============================

Jeder Entwickler der Apps baut, die als Dienst laufen. Administratoren, die solche Apps managen oder deployen.
