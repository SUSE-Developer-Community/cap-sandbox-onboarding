Bu belgeyi kim okumalı?
=======================

Herhangi bir çalışan uygulama geliştirenler. Bu tür uygulamaları dağıtan ve yöneten Ops mühendisleri.
