Dla kogo przeznaczony jest ten dokument?
==============================

Dla każdego developera tworzącego aplikacje, które działają jako usługa. Dla każdego Dev-opsa, który wdraża i zarządza takimi aplikacjami.
