Who should read this document?
==============================

Any developer building applications which run as a service.  Ops engineers who deploy or manage such applications.
